# Howls Moving City
A webgl application with three.js. It is basically a road construction simulation which uses the minimum spanning tree algorithm to show the best possible road between the buildings with djikstra algorithm.
