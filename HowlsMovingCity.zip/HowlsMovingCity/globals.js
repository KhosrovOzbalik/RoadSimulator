export const GRID_SIZE = 60;

export const selection = Object.freeze({
    BUILDING_1: "Building 1",
    BUILDING_2: "Building 2",
    ROCK: "Rock",
    TREE: "Tree",
    //DELETE: "delete",
})

/*Meshler zart zurt globaller buraya*/